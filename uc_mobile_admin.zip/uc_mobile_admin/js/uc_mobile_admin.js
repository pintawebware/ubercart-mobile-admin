var request = new XMLHttpRequest();
request.open("GET", '/ucmob.push');
request.send();