#Ubercart Mobile Admin

##Description

Ubercart shop administration from mobile devices

## Installing 
Install the module as normal, note that there are dependencies:
  - rest;
  - uc_order;
  - uc_product.
